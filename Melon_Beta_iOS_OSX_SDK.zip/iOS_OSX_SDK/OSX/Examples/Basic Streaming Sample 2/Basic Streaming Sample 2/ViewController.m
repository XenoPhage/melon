//
//  ViewController.m
//  Basic Streaming Sample 2
//
//  Created by Eric Lundquist on 3/18/15.
//  Copyright (c) 2015 DAQRI. All rights reserved.
//

#import "ViewController.h"
@import MelonPlatformKit;
@interface ViewController()<MPKSignalAnalyzerOutput>
@property (nonatomic,strong) MPKDeviceHandle * currentDevice;
@property (nonatomic,strong) MPKSignalAnalyzer * signalAnalyzer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


-(void)viewWillAppear{
    [super viewWillAppear];
    //register for BLE updates, in this case for as long as our view is visible.
    [self registerForBluetoothUpdates];
    //prepare signal analyzer.
    [self setupSignalAnalyzer];
    
    [[MPKBluetoothManager sharedManager] startSearchingForDevices];//start searching for devices.
}

- (void)viewWillDisappear{
    [super viewWillDisappear];
    //unregister for events
    [self unregisterForBluetoothUpdates];
    //tear down signal analyzer
    [self tearDownSignalAnalyzer];
}




- (void)registerForBluetoothUpdates {
    //The name of your update handler. Use this to remove the update handler or change what events cause the update handler to be called.
    NSString * updateHandlerKey =@"ViewController_Update_Handler";
    
    // tell the MPKBluetoothManager to only call the update handler when a connection, disconnection, removal or discovery event occurs.
    //the default is MPKDeviceUpdateAllReasons
    MPKDeviceUpdate reasons = MPKDeviceUpdateDidConnect|MPKDeviceUpdateDidDisconnect|MPKDeviceUpdateDidRemove|MPKDeviceUpdateDiscovered;
    [[MPKBluetoothManager sharedManager] setUpdateNotificationReasons:reasons forKey:updateHandlerKey];
    //set the update handler. This will be call when any of the events in the reasons mask occur.
    // NOTE: MPKDeviceUpdate bitmasks are only used by the SDK to set/toggle events. The 'reason' parameter passed to your update handler will always be a single value
    //for the event that occured.
    
    [[MPKBluetoothManager sharedManager] setUpdateHandler:^(MPKDeviceUpdate reason, MPKDeviceHandle * device) {
        //Handle the event.
        //NOTE: 'self' is captured strongly in this block, it will be retained until you call
        // [[MPKBluetoothManager sharedManager] setUpdateHandler:NULL forKey:updateHandlerKey]
        [self handleUpdate:reason device:device];
        
    } forKey:updateHandlerKey];
}
- (void)unregisterForBluetoothUpdates {
    //Unregister the event handler for 'ViewController_Update_Handler'
    // NOTE: setting your update handler to NULL will not disconnect any devices or stop any signal analyzers currently running.
    [[MPKBluetoothManager sharedManager] setUpdateHandler:NULL forKey:@"ViewController_Update_Handler"];
}

- (void)setupSignalAnalyzer {
    _signalAnalyzer = [MPKSignalAnalyzer analyzer];//Use the out of the box signal analyzer.
    _signalAnalyzer.analysisRate = 32.0f/(float)MPKDefaultSamplingRate; //Analyze every 32 frames (0.128 seconds).
    _signalAnalyzer.leftChannelEnabledDataProcesserTypes = MPKDataProcesserTypeFocusAlgorithm|MPKDataProcesserTypeSignalValidation;//enable focus and signal validation.
    _signalAnalyzer.rightChannelEnabledDataProcesserTypes = MPKDataProcesserTypeSignalValidation;//enable just signal validation.
    //NOTE: MPKDataProcesserTypeFFT is implicit when MPKDataProcesserTypeFocusAlgorithm or MPKDataProcesserTypeSignalValidation is specified.
    
}

- (void)tearDownSignalAnalyzer{
    [_signalAnalyzer removeOutput:self];//remove ourself from the analyzer
    [_signalAnalyzer removeFromSignalStream];//remove analyzer from its parent signal stream (if it has one)
    _signalAnalyzer = nil;
}
- (void)resetSignalAnalyzer {
    [_signalAnalyzer removeFromSignalStream];
    [_signalAnalyzer removeOutput:self];
    [_signalAnalyzer reset];
}

- (void)startAnalyzing{
    //reset signal analyzie if its running
    [self resetSignalAnalyzer];
    //add self (which conforms to MPKSignalAnalyzerOutput) as an output.
    [_signalAnalyzer addOutput:self];
    // add the analyzer to the devices stream.
    [_currentDevice.stream addOutput:_signalAnalyzer];
    
    _signalAnalyzer.enabled = YES;//enable it.
    [_currentDevice startStreaming];//open the device stream. (its safe to call this if the device is already streaming)
    
}

- (void)stopAnalyzing {
    [_currentDevice stopStreaming];//stop streaming.
    [self resetSignalAnalyzer];
}

- (void)handleUpdate:(MPKDeviceUpdate)update device:(MPKDeviceHandle *)handle{
    switch (update) {
        case MPKDeviceUpdateDiscovered: {
            //connect to the first available device.
            [handle connect];
            _currentDevice = handle;
            break;
        }
        case MPKDeviceUpdateDidConnect: {
            
            [self startAnalyzing];//Start analyzing data from the device.
            
            break;
        }
        case MPKDeviceUpdateDidDisconnect: {
            [self stopAnalyzing];//remove ourself from the devices stream.
            
            _currentDevice = nil;
            
            break;
        }
            
            
        case MPKDeviceUpdateDidRemove: {
            if (_currentDevice==handle){//check that the event occured for our device.
                [self stopAnalyzing];//remove ourself from the devices stream.
                [[MPKBluetoothManager sharedManager] startSearchingForDevices];//start searching for devices again.
            }
            break;
        }
            
        default:
            break;
    }
}
-(void)signalAnalyzerDidEnterIdleState:(MPKSignalAnalyzer *)analyzer {
    NSLog(@"Poor electrode contact detected, entering idle state.");
}
-(void)signalAnalyzerDidLeaveIdleState:(MPKSignalAnalyzer *)analyzer {
    NSLog(@"Leaving idle state. ");
}

-(dispatch_queue_t)methodInvocationQueueForSignalAnalyzer:(MPKSignalAnalyzer *)analyzer {
    //return a queue you want the MPKSignalAnalyzerOutput methods to be called on.
    //NOTE: If you are processing the data in the callbacks using the main queue isnt advised.
    return dispatch_get_main_queue();
}
//invoked when the analyzer analyzes data. (in this case every 32 frames)
- (void)signalAnalyzerDidPerformAnalysis:(MPKSignalAnalyzer *)analyzer onChannels:(MPKChannelSet *)channels {
    [self doSomethingWithTheFocus:channels];
    //uncomment to the below methods to print different data to the log.
    /*
     [self doSomethingWithTheLastFiltered32FramesABunchOfDifferentWays:channels];
     [self doSomethingWithLastRaw32FramesOneWay:channels];
     [self doSomethingWithTheLastSamplingRatesWorthOfDataPoints:channels];
     */
}
- (void)doSomethingWithTheLastFiltered32FramesABunchOfDifferentWays:(MPKChannelSet *)channels {
    MPKChannelDescription * leftChannel = channels.leftChannel;
    NSRange leftSampleRange = leftChannel.analysisSampleRange;//the range of the last data sample analyzed. This range is the same for the left and right channel for stereo analyzers (the default)
    //get a buffer with the data in sample range for the left channel and print the values of it.
    MPKFloatBuffer * leftFilteredSample = [leftChannel.filteredSignal subBufferInRange:leftSampleRange];
    [leftFilteredSample enumerate:^(float mV, NSUInteger index, BOOL *stop) {
        NSLog(@"Left Channel Value: %f",mV);
    }];
    
    MPKChannelDescription * rightChannel = channels.leftChannel;
    NSRange rightSampleRange = rightChannel.analysisSampleRange;//the range of the last data sample analyzed.  This range is the same for the left and right channel for stereo analyzers (the default)
    //you can also just enumerate over a buffer if you dont need to require a buffer to be created. (this is usually more efficient)
    [rightChannel.filteredSignal enumerateInRange:rightSampleRange withBlock:^(float mV, NSUInteger index, BOOL *stop) {
        NSLog(@"Right Channel Value: %f",mV);
    }];
    
    //The data from each channel is in sync so it's safe to do something like this as well.
    [rightChannel.filteredSignal enumerateInRange:rightSampleRange withBlock:^(float rightChannelMv, NSUInteger index, BOOL *stop) {
        float leftChannelMv = leftChannel.filteredSignal.floatArray[index];
        NSLog(@"Left %f and Right %f values",leftChannelMv,rightChannelMv);
    }];
    
    //or
    
    for (NSUInteger i = rightSampleRange.location; i < NSMaxRange(rightSampleRange);i++){
        float leftChannelMv = leftChannel.filteredSignal.floatArray[i];
        float rightChannelMv = rightChannel.filteredSignal.floatArray[i];
        NSLog(@"Left %f and Right %f again",leftChannelMv,rightChannelMv);
    }
    
    
}


- (void)doSomethingWithLastRaw32FramesOneWay:(MPKChannelSet *)channels {
    //same as whats covered in -doSomethingWithTheLastFiltered32FramesABunchOfDifferentWays: but with raw signal.
    MPKChannelDescription * leftChannel = channels.leftChannel;
    NSRange leftSampleRange = leftChannel.analysisSampleRange;
    MPKFloatBuffer * leftRawSample = [leftChannel.rawSignal subBufferInRange:leftSampleRange];
    [leftRawSample enumerate:^(float mV, NSUInteger index, BOOL *stop) {
        NSLog(@"Left Raw Value: %f",mV);
    }];
}

- (void)doSomethingWithTheFFT:(MPKChannelSet *)channelSet {
    //The results of the FFT are stored in the MPKDFT class.
    MPKDFT * leftFilteredDFT = [channelSet.leftChannel filteredDFT];//results of the FFT performed on the left channel filtered data.
    
    if (leftFilteredDFT){
        NSIndexSet * freqIdxs = [leftFilteredDFT.frequencies indexesOfValuesPassingTest:^BOOL(float frequency, NSUInteger idx, BOOL *stop) {
            return frequency>=1.0f && frequency<=4.0f;//get indexes of frequencies between 1.0-4.0hz
        }];
        
        MPKFloatBuffer * deltaWaveAmplitude = [leftFilteredDFT.amplitude bufferWithValuesAtIndexes:freqIdxs];
        NSLog(@"Peak delta power: %f",deltaWaveAmplitude.maxFloatValue);
    }
    //you can also access the amplitude data for a specific frequency range like this:
    MPKFloatBuffer * thetaWaveAmplitude = [channelSet.leftChannel filteredAmplitudeInFrequencyRange:MPKFrequencyRangeMake(4.0, 7.0)];
    NSLog(@"Mean theta power: %f",thetaWaveAmplitude.meanFloatValue);
    
}

- (void)doSomethingWithTheLastSamplingRatesWorthOfDataPoints:(MPKChannelSet *)channelSet {
    MPKFloatBuffer * filteredSignal = channelSet.leftChannel.filteredSignal;
    NSUInteger sampRate = channelSet.leftChannel.samplingRate;//250 hz.
    NSRange rng = NSMakeRange(filteredSignal.size-sampRate, sampRate);
    MPKFloatBuffer * last250 = [filteredSignal subBufferInRange:rng];
    NSLog(@"Left channel last 250 Mean:%f Median:%f",last250.meanFloatValue,last250.medianFloatValue);
    
}

- (void)doSomethingWithTheFocus:(MPKChannelSet *)channels {
    float focus = channels.leftChannel.focusScore.floatValue;//We set our analyzer to only calculate focus using the left channel.
    NSLog(@"Left channel focus: %f/100",focus*100.0f);
}

@end
