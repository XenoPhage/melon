//
//  AppDelegate.m
//  Basic Streaming Sample 2
//
//  Created by Eric Lundquist on 3/18/15.
//  Copyright (c) 2015 DAQRI. All rights reserved.
//

#import "AppDelegate.h"
@import MelonPlatformKit;
@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    [MelonPlatformKit handleApplicationLaunch];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
