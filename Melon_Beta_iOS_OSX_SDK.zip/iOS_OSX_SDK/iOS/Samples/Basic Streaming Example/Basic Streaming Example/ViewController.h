//
//  ViewController.h
//  Basic Streaming Example
//
//  Created by Eric Lundquist on 3/18/15.
//  Copyright (c) 2015 DAQRI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

