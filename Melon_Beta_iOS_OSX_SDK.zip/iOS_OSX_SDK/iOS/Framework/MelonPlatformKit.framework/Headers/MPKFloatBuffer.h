//
//  MPKFloatBuffer.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 10/16/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol MPKFilter;
/*! @brief A highly optimized collection class used to store a floats.
 *
 * MPKFloatBuffer is a contextually mutable collection used to store floating point values and cache common mathematical
 * operations done to it. The MPKFloatBuffer is incredibly fast at making circular insertions making it ideal for
 * "pushing" and "popping" large amounts of data aquired from a time series.
 *
 * The MPKFloatBuffer also uses an intelligent caching system that caches common operations performed on it such as
 * calculating the mean or median. The caching system also caches the stored data only once it's accessed after a change.
 * This means that subsequent calls to -getFloatArray, -floatArray, -createFloatArray etc are all able to copy or return
 * their data from the same location in memory without having to iterate through the double ended queue structure multiple
 * times. This makes data access incredibly fast for subsequent calls to these methods.
 *
 * MPKFloatBuffer is ideal for when two classes share the data stored in the MPKFloatBuffer but don't need to know the each
 * other exists. This is often the case when chaining data processeors together in a signal stream buffer.
 *
 *
 * NOTE: That while the MPKFloatBuffer does provide excellent performance for it's intended use, there are some draw backs.
 * Mainly memory usage. MPKFloatBuffer's may use anywhere between 1 to 3 times the memory you'd expected it to use to store
 * it's values. This is do to how it implements caching.
 *
 * When you add 1 element to an MPKFloatBuffer it is added to the back and 1 element is removed from the front.
 * At this point so the buffer uses about as much memory as you'd expect, sizeof(float) * the
 * size of the buffer. As soon as you access the underlying float array directly, an alligned chunk of memory is allocated
 * to store the array for subsequent reads. This is due to the fact that iterating through a double ended queue is much
 * slower than a primitve array. Now you are using 2x the memory. Now lets say you access the sortedFloatArray, at this point
 * a 3rd chunk of memory is allocated and cached and you are using 3x the amount of memory.
 * Every time you add a value the buffer, its caches are invalidated but not freed. This prevents needing to constantly
 * allocate new memory everytime a cached value is accessed.
 * If you call -convertToImmutable you can guarentee that the maximum memory usage will only ever reach 2x.
 *
 * Because of the behaviour outlined above, you should avoid situations where the cache is invalidated and then accessed
 * repeatedly. Below is an example of a do and don't sitatuation
 *
 * DONT: Constantly force recaching to happen by adding data then requesting an operation that validates the cache.
 *      float * someData = ...;
 *      MPKFloatBuffer * buffer = ...;
 *      for (int i = 0; i < count;i++){
 *          [buffer push:someData[i]];//cache marked as invalid
 *          performAutoCorrelation(buffer.floatArray); // call to -floatArray revalidates the cache every cycle of the loop.
 *      }
 *
 * DO: Add your data in batches and validate the cache at a later point.
 *      float * someData = ...;
 *      MPKFloatBuffer * buffer = ...;
 *      for (int i = 0; i < count;i++){
 *          [buffer push:someData[i]];//cache marked as invalid
 *      }
 *
 *      performAutoCorrelation(buffer.floatArray); // call to -floatArray revalidates the cache, but only once.
 *
 *
 *
 *
 *
 *
 *  When to use MPKFloatBuffer:
 *  - You need to store a fixed number of float values that in a way such that every time a value is added the first is
 *    removed. (i.e the front is popped every time the back is pushed)
 *  - You need to access the primitive values frequently.
 *  - You need to perform operations that would require converting an NSArray to a primitive array of floats. An example
 *    would be using the accelerate frameworks vDSP functions.
 *  - You are writing an MPKDataProcessor.
 *  - You are sharing the data between multiple classes that may benefit from the cache of common operations such as the
 * mean, median, stddev etc etc.
 *
 * When not to use MPKFloatBuffer:
 *  - You need a dynamically sizing collection.
 *  - You need to store non-float values
 *  - You need random insertions
 *
 *
 *
 *
 *
 * Things to consider:
 * - When possible, try to use immutable buffers. They require less memory and their caches are never invalidated unless you
 * convert the buffer back to mutable.
 * - If you're just reading the data don't use getFloatArray:, it performs a copy to the pointer you provide. Just access the
 *   data directly -floatArray.
 * - When enumerating, caches are automatically validated if needed unless you stop the enumeration.
 * - Performing concurrent enumeration will always validate the cache if needed, stopping the enumeration only prevents you
 *   enumeration block from being called.
 * -
 *
 * @attention MPKFloatBuffer mutability only applies to adding data (contextually mutable). When an MPKFloatBuffer is marked
 * immutable, you can still modify the values in its underlying backing store via -floatArray. But using any of the
 * push methods will throw an exception.
 *
 *
 */

@interface MPKFloatBuffer : NSObject<NSCopying,NSCoding>
/*! @brief The fixed size the buffer was initialized with.
 *
 */
@property (nonatomic,assign,readonly) NSUInteger size;

/*! @brief Specifies whether or not the buffer can have data added to it via any of the push methods the underlying data can still be maniuplated.
 *
 * @discussion
 * When immutable is set from NO to YES, the buffer will release the backing store use for quick inserts and all internally cached values are rebuilt if
 * needed. While immutable, access to the values are much faster. You are also able to mutate the array returned by -floatArray directly (i.e 
 * vDSP_something(values, &(buffer.floatArray))) instead of copying the contents.
 *
 * When immutable is set from YES to NO, the buffer will merge any changes made to -floatArray with the underlying backing store used for quick inserts and 
 * clear any caches stored in the buffer. The next time you access a cacheable value, it will be recalculated using the updated values.
 * Converting a buffer from immutable back to mutable should be avoided if possible, as it incurs a performance penalty.
 *
 * @attention While immutable, any of the push operations will throw an exception.
 */

@property (nonatomic,assign,getter=isImmutable) BOOL immutable;
/*! @brief Initializes an immutable float buffer with an array of floats and optionally copies it.
 *
 * @attention If you specify that the data should not be copied, the MPKFloatBuffer will free the data when it's finished.
 * If you initialize the buffer using an array on the stack you must copy it.
 *  @param data array of floats to intialize the buffer with.
 *  @param size the number of elements in data.
 *  @param copy specify whether the data should be copied or not. If the data is not copied it will be freed when the buffer
 *         has its dealloc method called
 *
 */
- (instancetype)initWithFloats:(float *)data size:(NSUInteger)size copy:(BOOL)copy;
/*! @brief Initializes an immutable float buffer with an array of floats and copies it.
 *  @param data array of floats to intialize the buffer with.
 *  @param size the number of elements in data.
 */
- (instancetype)initWithFloats:(float *)data size:(NSUInteger)size;
/*! @brief Initializes a mutable float buffer with a fixed size.
 * The buffer is initialized with zeros
 * @param size the size of the buffer
 */
- (instancetype)initWithSize:(NSUInteger)size;
/*! @brief Adds a new value to the back of the buffer and removes one from the front.
 
 * @param v the value to add.
 */
- (void)push:(float)v;
/*! @brief Adds the content of another buffer to the back and removes from the front the same number elements added.
 * @param buffer the buffer to push.
 */
- (void)pushBuffer:(MPKFloatBuffer *)buffer;
/*! @brief Adds an array of floats to the back of the buffer and removes the number of elements added from the front
 * @param values the buffer to add values from.
  @param size the number of elements in the values array.
 */
- (void)pushValues:(float *)values size:(NSUInteger)size;
/*! @brief Enumerates the buffer in the range specified
 *  This method validates the cache if needed as long as the entire buffer is enumerated. Subsequent calls use the cache
 *  until it is invalidated.
 * @param block the block to enumerate with
 * @param range the range to enumerate
 */
- (void)enumerateInRange:(NSRange)range withBlock:(void(^)(float v, NSUInteger index, BOOL *stop))block;
/*! @brief Enumerates through the buffer.
 *  This method validates the cache if needed as long as the entire buffer is enumerated. Subsequent calls use the cache 
 *  until it is invalidated.
 * @param block the block to enumerate with
 */
- (void)enumerate:(void(^)(float v, NSUInteger index, BOOL *stop))block;
/*! @brief Enumerates through the buffer.
 *  This method validates the cache if needed even if the enumeration is stopped, stopping it only prevents your block from 
 *  being called. Subsequent calls use the cache until it is invalidated.
 * @param block the block to enumerate with
 */
- (void)enumerateConcurrent:(void(^)(float v, NSUInteger index, BOOL *stop))block;
/*! @brief Copies the buffer contents in to an array you provide that can hold at least as many elements as the buffer.
 * @attention This method will not validate cache but it will use the cache if available.
 * @param array an array to copy the data into.
 */
- (void)getFloatArray:(float *)array;

/*! @brief Allocates a new array with the buffers contents and optionally.
 *  You are responsible for freeing this array.
 * @attention This method will validate the cache.
 * @return a float array on the heap with the contents of the buffer.
 */
- (float *)createFloatArray;
/*! @brief Direct access to the cached backing store containing the contents of the buffer.
 *
 * @attention You may mutate the contents of this array, however if the buffer is not immutable, you must manually 
 * synchronize and invalidate the caches before using any of the -push methods after a mutation has occured. If you don't 
 * invalidate the caches your data will most likely be corrupted the next time a value is added. If you have called -
 * sortedFloatArray prior to mutating the array returned by this method you must also invalidate its cache manually.
 * If the buffer is immutable, you do not need to call synchronize.
 */
- (float *)floatArray;
/*! @brief Returns a sorted float array of the contents stored in the buffer.
 *
 * This method will validate the cache if needed, allocate new space for the sorted array and add it to the cache.
 * subsequent calls to this method will use the cached version.
 *
 * @attention Any mutations made to -floatArray will not be reflected in the value returned from this array if it is using 
 * a cached result. You must manually -invalidateCaches the caches.
 *
 */
- (const float *)sortedFloatArray;
/*! @brief Fills a float array with the values at the indexes specified by indexSet.
 * @param indexSet the index set of the values to populate the array with.
 * @param array the array to populate.
 * @attention array must be at least indexSet.count*sizeof(float) in size.
 */
- (void)getFloatArray:(float *)array atIndexes:(NSIndexSet *)indexSet;

/*! @brief Creates a mutable buffer with the values specified in the range
 * This method validates the cache if needed.
 * @param range the range of values to create the buffer with.
 * @return a MPKFloatBuffer with the values in the specified range.
 */
- (MPKFloatBuffer *)subBufferInRange:(NSRange)range;
/*! @brief Creates an immutable buffer with the values specified in the range
 * This method validates the cache of both buffers.
 *
 */
- (MPKFloatBuffer *)immutableSubBufferInRange:(NSRange)range;
 
/*! @brief Returns the indexes of float values where you block returned YES.
 * This method validates the cache if needed and subsequent calls to it use the cache.
 * @param predicate the block used as a predicate
 * @return the index set of the floats satisfying the predicate.
 *
 */
- (NSIndexSet *)indexesOfValuesPassingTest:(BOOL (^)(float f, NSUInteger idx, BOOL *stop))predicate;
/*! @brief Creates an immutable buffer using the floats at the indexes of specified by the index set
 * This method validates the cache if needed and subsequent calls to it use the cache.
 * @param indexSet the set of indexes for the floats being used to create the buffer.
 */
- (MPKFloatBuffer *)bufferWithValuesAtIndexes:(NSIndexSet *)indexSet;

/*! @brief Creates an immutable copy of the buffer.
 * This buffer cannot have insertions made to it unless it is converted back to mutable.
 * @return an immutable copy of the reciever
 */
- (MPKFloatBuffer *)immutableCopy;

/*! @brief Creates a copy of the buffer after applying filter.
 *
 * @return a copy of the buffer after apply a filter to it.
 */
- (MPKFloatBuffer *)bufferByApplyingFilter:(id<MPKFilter>)filter;
/*! @brief Creates an NSArray of NSNumbers using the contents of the buffer.
 *  This method validates the cache and the result itself is cached. Subsequent calls use the cache. 
 * @return an NSArray with the contents of the buffer.
 */
- (NSArray *)allObjects;

/*! @brief creates a copy of the reciever after multiply every element by scale.
 * @return a copy of the reciever after multiply every element by scale.
 */
- (MPKFloatBuffer *)scaledBuffer:(float)scale;
/*! @brief Scales the buffer by multiplying every element by a scale.
 * This method validates the cache if needed. 
 *
 */
- (void)scale:(float)scale;
/*! @brief creates a copy of the reciever containing the absolute value of every element
 * @return a copy of the reciever containing the absolute value of every element.
 */
- (MPKFloatBuffer *)absoluteBuffer;
/*! @brief Replaces every element in the receiver with its absolute value.
 *
 *
 */
- (void)absolute;
/*! @brief Creates a new buffer with the decibel values of the original values.
 *
 *
 */
- (MPKFloatBuffer *)decibelBuffer;
/*! @brief Synchronizes any mutations made to the underlying backing store
 * You must call this if you've made mutated the result of the -floatArray method before accessing cached values you wish to have reflect the change.
 * @attention If you are changing the the value of the immutable property after changed -floatArray calling this method is not needed.
 *
 *
 */
- (void)processDirectMutations;



/*! @brief The smallest value in the buffer
 * Subsequent reads of this property are cached.
 */
@property (nonatomic,assign,readonly) float minFloatValue;
/*! @brief The largest value in the buffer
 * Subsequent reads of this property are cached.
 */
@property (nonatomic,assign,readonly) float maxFloatValue;
/*! @brief checks if the buffer contains NaNs
 * this method validates the cache and its result is also cached. Subsequent calls use the cached result.
 * @return YES if nans are present, NO otherwise.
 */
- (BOOL)containsNaNs;
/*! @brief Calculates the standard deviation of the buffer.
 * this method validates the cache and its result is also cached. Subsequent calls use the cached result.
 * @return the standard deviation of the buffer.
 */
- (float)standardDeviation;
/*! @brief Calculates the mean of the buffer.
 * this method validates the cache and its result is also cached. Subsequent calls use the cached result.
 * @return the mean of the buffer.
 */
- (float)meanFloatValue;
/*! @brief Calculates the median of the buffer.
 * this method validates the cache and its result is also cached. Subsequent calls use the cached result.
 * @return the median of the buffer.
 */
- (float)medianFloatValue;
@end


@interface MPKFloatBuffer(Benchmark)
+ (void)benchmark:(NSUInteger)size operations:(NSUInteger)count;
+ (void)benchmarkCustomOperationSize:(NSUInteger)size
                      operationCount:(NSUInteger)count
                     bufferOperation:(BOOL(^)(MPKFloatBuffer * floatBuffer,int operation)) bufferBlock
                      arrayOperation:(BOOL(^)(NSMutableArray * array,int operation)) arrayBlock
                               title:(NSString *)title;
@end
