//
//  MPKSignalDescription.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 9/3/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MPKDefines.h"
#import "MPKDFT.h"
@class MPKFloatBuffer;
@class MPKChannelSet;
@class MPKDFT;
/*! @brief An opaque class containing the results of processing data from a channel via an MPKSignalAnalyzer.
 * MPKChannelDescription's are created by MPKSignalAnalyzers every time data is processed.
 * Every description is passed to the data processors (objects conforming to MPKDataProcessor)
 * in the MPKSignalAnalyzer and update the MPKChannelDescription if needed. This allows for 
 * things like FFT and signal validity to be reused between data processors resulting in less
 * resources being consumed. 
 *
 *
 * What this class contains by defualt:
 * - Raw and Filtered signal
 * - The most recent sample data (based on the analysisRate of the MPKSignalAnalyzer)
 * - Results of the FFT if enabled
 * - Focus scores if enabled
 * - Various information about the signal at the time the description was created
 *
 * @attention This is the preferred way of reading, writing and storing data from the headband.
 * 
 * 
 * CONTINUE READING if you plan to implement a class conforming to MPKDataProcessor and write to 
 * MPKChannelDescription objects.
 * 
 * Things to know when writing to an MPKChannelDescription:
 * 1. The properties defined by MPKChannelDescription are reserved for the default classes
 * conforming to MPKDataProcessor some of which are private. Never attempt to set them.
 *
 * 2. MPKChannelDescription supports dynamic storage a data via the KVC access methods. (i.e
 * setValue:forKey:) this is how your custom data processor should store its data.
 *
 * 3. You may extend MPKChannelDescription and define @dynamic properties in your extension. 
 * This allows for more convenient access of customly stored data. 
 * 
 * 4. Your custom data must conform to NSCopying and NSCoding.
 *
 * 5. It is never safe to write to an MPKChannelDescription after outside of using a custom data 
 * processor. MPKSignalAnalyzer outputs should NEVER write data to a description.
 * 
 * 6. Review the sample project for examples of how to implement custom data processing.
 */


@interface MPKChannelDescription : NSObject <NSCopying,NSCoding>

/*! @brief The channel set the description belongs to.
 */
@property (nonatomic,weak,readonly) MPKChannelSet * channelSet;
/*! @brief Specifies whether or not the description contains FFT results for the raw signal.
 * This value is based on settings from the MPKSignalAnalyzer.
 * When NO, this description will have nil values for rawAmplitude and rawFrequencies.
 *
 * @attention if you're custom data processor computes an FFT using raw signal, it use this value
 * as a hint to skip making updates.
 *
 */
@property (nonatomic,assign,readonly) BOOL includesRawSignalFFTResults;
/*! @brief The number of cycles that have been processed by the analyzer generating the description.
 *
 *
 */
@property (nonatomic,assign,readonly) NSUInteger cycles;
/*! @brief The channel that this description represents
 *
 */
@property (nonatomic,assign,readonly) NSUInteger channel;
/*! @brief The range of the data points that were used for analysis.
 * This will be the last (samplingRate*analysisRate) data points.
 */
@property (nonatomic,assign,readonly) NSRange analysisSampleRange;
/*! @brief The raw unfiltered signal.
 *
 */
@property (nonatomic,strong,readonly) MPKFloatBuffer * rawSignal;
/*! @brief The filtered signal.
 *
 */
@property (nonatomic,strong,readonly) MPKFloatBuffer * filteredSignal;
/*! @brief The sampling rate of the analyzer that generated the description
 *
 */
@property (nonatomic,assign,readonly) NSUInteger samplingRate;
/*! @brief The analysis rate factor of the analyzer that generated the description
 *
 */
@property (nonatomic,assign,readonly) float analysisRate;
/*! @brief The time the description was generated.
 *
 */
@property (nonatomic,strong,readonly) NSDate * timestamp;
/*! @brief Contains the DFT results of performing FFT on the filtered signal
 *
 */
@property (nonatomic,strong,readonly) MPKDFT * filteredDFT;
/*! @brief Contains the DFT results of performing FFT on the filtered signal
 *
 */
@property (nonatomic,strong,readonly) MPKDFT * rawDFT;
/*! @brief The focus score on a 0.0 - 1.0 scale or nil if the focus score could not be calculated.
 *@attention This value may be nil right as the device starts streaming.
 */
@property (nonatomic,strong,readonly) NSNumber * focusScore;

/*! @brief The status of the FFT
 *
 *
 * MPKChannelAttributeStatusUnknown, the fft could not be calculated
 * MPKChannelAttributeStatusValid, the fft is valid
 * MPKChannelAttributeStatusInvalid, the fft is invalid. (contains NaN's etc)
 */
@property (nonatomic,assign,readonly) MPKChannelAttributeStatus fftStatus;
/*! @brief The status of the signal
 *
 *
 * MPKChannelAttributeStatusUnknown, the signal status could not be determined
 * MPKChannelAttributeStatusValid, the signal is within acceptable ranges for electrode contact with skin
 * MPKChannelAttributeStatusInvalid,the signal is NOT within acceptable ranges for electrode contact with skin
 */
@property (nonatomic,assign,readonly) MPKChannelAttributeStatus signalStatus;
/*! @brief Specifies whether or not the signal is most likely noise (i.e the electodes are not making contact with skin)
 *
 * This value will be calculated using MPKDataProcesser's that support idle signal recognition.
 */
@property (nonatomic,assign,readonly,getter = isIdle) BOOL idle;


/*! @brief returns the filtered amplitude in the frequency range
 *
 
 */
- (MPKFloatBuffer *)filteredAmplitudeInFrequencyRange:(MPKFrequencyRange)range;

/*! @brief returns the raw amplitude in the frequency range
 *
 
 */
- (MPKFloatBuffer *)rawAmplitudeInFrequencyRange:(MPKFrequencyRange)range;
/*! @brief Copies the channel description without copying it's collection classes.
 *
 * This is useful when retaining a lot of channel descriptions where the signal data are not needed. (i.e just status, focus score, dc offset etc)
 */
- (instancetype)copyWithoutPreservingCollections;
/*! @brief Copies the channel description without copying it's collection classes except for the ...AnalyzedSample array's
 *
 * This is useful when retaining a lot of channel descriptions where the signal data are not needed. (i.e just status, focus score, dc offset etc)
 */
- (instancetype)copyPreservingAnalysisResultsOnly;
/*! @brief Retrieves the filtered signal in a range as a float array.
 * Subsequent calls to this method memcpy a cached array so they are more effiecient if you have to
 * use the arrays as scalar values often.
 */
- (void)getFilteredSignal:(float *)filteredSignal inRange:(NSRange)range;
/*! @brief Retrieves the filtered signal.
 * Subsequent calls to this method memcpy a cached array so they are more effiecient if you have to
 * use the arrays as scalar values often.
 */
- (void)getFilteredSignal:(float *)filteredSignal;
/*! @brief Direct access to filtered signal as a float array.
 * Subsequent calls to this return a cached array so they are more effiecient if you have to
 * use the scalar values often. 
 *
 * @attention YOU MUST NEVER mutate the values inside of the array. If you need to do that, use the getFiltered signal methods. 
 */
- (const float *)filteredSignalFloatArray;

/*! @brief Retrieves the raw signal in a range as a float array.
 * Subsequent calls to this method memcpy a cached array so they are more effiecient if you have to
 * use the arrays as scalar values often.
 */
- (void)getRawSignal:(float *)sigOut;
/*! @brief Retrieves the raw signal.
 * Subsequent calls to this method memcpy a cached array so they are more effiecient if you have to
 * use the arrays as scalar values often.
 */
- (void)getRawSignal:(float *)sigOut inRange:(NSRange)range;
/*! @brief Direct access to raw signal as a float array.
 * Subsequent calls to this return a cached array so they are more effiecient if you have to
 * use the scalar values often.
 *
 * @attention YOU MUST NEVER mutate the values inside of the array. If you need to do that, use the getRaw.. signal methods.
 */
- (const float *)rawSignalFloatArray;
/*! @brief Sets an object for a keyed subscript. (i.e myDescription[@"myCoolKey"] = myCoolObject;)
 *  This method allows you to easily add your own custom values to MPKChannelDescription objects (which cannot be subclassed) via
 *  custom data processors.
 *
 *  @attention the only requirement is that the key provided must be an NSString. It is also safe to pass nil to remove an object
 *
 */
-(void)setObject:(id)obj forKeyedSubscript:(id<NSCopying>)key;
/*! @brief This method returns an object the key provided.
 *  This method allows you to easily retrieve your own custom values from MPKChannelDescription objects (which cannot be subclassed) via
 *  custom data processors.
 *
 *  @attention the only requirement is that the key provided must be an NSString.
 *
 */
-(id)objectForKeyedSubscript:(id)key;
@end
