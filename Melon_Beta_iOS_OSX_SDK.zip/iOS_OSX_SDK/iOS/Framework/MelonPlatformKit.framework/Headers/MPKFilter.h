//
//  MPKFilter.h
//  Melon Platform
//
//  Created by Eric L on 3/29/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MPKDefines.h"
extern const float MPKButterworthQFactor;
extern const float MPKBesselQFactor;
extern const float MPKCriticalQFactor;
@class MPKFloatBuffer;

/*! @brief The protocol to which all default filters conform. Subclasses of any of the MPKFilter classes must also conform to this
 * protocol.
 *
 */
@protocol MPKFilter <NSObject,NSCopying>
/*! @brief Filters an array of floats in place.
 *
 * @param data the data to filter.
 * @param length the length of the data array.
 *
 */
- (void)filter:(float *)data length:(NSUInteger)length;
/*! @brief Filters an array of NSNumber objects
 *
 * @param array an array of NSNumber objects.
 *
 * @return a filtered array of NSNumber objects equal in size to the original array.
 *
 */
- (NSArray *)filteredArray:(NSArray *)array;

/*! @brief Filters an array of NSNumber objects
 *
 * @param array an array of NSNumber objects.
 *
 * @return a filtered array of NSNumber objects equal in size to the original array.
 *
 */
- (MPKFloatBuffer *)filteredFloatBuffer:(MPKFloatBuffer *)array;

/*! @brief Creates a copy of the filter adjusted to use a different sampling rate
 *
 * @param samplingRate The new sampling rate to use.
 *
 * @return a copy of the filter adjusted to use a different sampling rate
 *
 * @attention When calling this method on an MIIRFilter or MPKFIRFilter filter an unchanged copy of the filter is returned.
 */
- (id<MPKFilter>)filterWithSamplingRate:(NSUInteger)samplingRate;
/*! @brief Resets the filter's memory.
 *
 *  The default filters retain a memory of the previous values passed through the filter.
 * This allows you to filter continuous data in chunks without ringing artifacts. Calling this method clears that
 * memory.
 *
 * @attention This method is called for you when your filter is associated with an MPKSignalAnalyzer.
 *
 *
 */
- (void)reset;


@end
/*! @brief A basic filter used to filter time series.
 *
 *  Use this class to design common filters such as notch or bandpass filters.
 *
 *
 */
@interface MPKBasicFilter : NSObject<MPKFilter>
/*! @brief The type of filter the instance was intialized with
 *
 *
 */
@property (nonatomic,assign,readonly) MPKFilterType type;
/*! @brief The centerFrequency of the filter.
 *
 *
 */
@property (nonatomic,assign,readonly) float centerFrequency;
/*! @brief The qFactor (i.e the Quality Factor) of the filter.
 *
 *
 */

@property (nonatomic,assign,readonly) float qFactor;
/*! @brief The samplingRate of the filter.
 *
 *
 */
@property (nonatomic,assign,readonly) float samplingRate;
/*! @brief The frequency range of the filter.
 *
 *
 */
@property (nonatomic,assign,readonly) MPKFrequencyRange range;
/*! @brief Specifies if the filter is range or center frequency based.
 *
 *
 */
@property (nonatomic,assign,readonly) BOOL isRangeBased;
/*! @brief Inititalizes a filter with a type, center frequency, sampling rate and Q factor.
 *
 *  Use this intitializer for filters that don't require a range, e.g., a Notch filter.
 *
 * @returns an initialized MBasicFilter instance.
 */
- (instancetype)initWithType:(MPKFilterType)type centerFrequency:(float)freq samplingRate:(float)rate qFactor:(float)qFactor;
/*! @brief Inititalizes a filter with a type, sampling rate and frequency range
 *
 *  Use this intitializer for filters that require a range.
 *
 * @returns an initialized MBasicFilter instance. The q factor and center frequency will be calcuated for you based on the
 * the filter type, sampling rate and range.
 */
- (instancetype)initWithType:(MPKFilterType)type samplingRate:(float)rate range:(MPKFrequencyRange)range;
/*! @brief Inititalizes a filter with a type, sampling rate and frequency range and Q factor
 *
 *  Use this intitializer for filters that require a range.
 *
 * @returns an initialized MBasicFilter instance. The q factor and center frequency will be calcuated for you based on the
 * the filter type, sampling rate and range.
 */
- (instancetype)initWithType:(MPKFilterType)type samplingRate:(float)rate range:(MPKFrequencyRange)range qFactor:(float)q;

/*! @brief Calculates an ideal Q factor based on a sampling rate and frequency range.
 *
 *
 */
+ (float)calculateQFactorForSamplingRate:(float)samplingRate inRange:(MPKFrequencyRange)range;
@end

/*! @brief A filter that chains any filter conforming to MPKFilter togther to perform multiple filter operations.
 *
 *  Use this filter to efficiently chain multiple filters together.
 *
 */
@interface MPKCompoundFilter : NSObject <MPKFilter,NSCopying>
/*! @brief Initializes the filter with an array of filters to chain together
 *
 * @param filters An array of filters to chain together. The filters are chained in the same order they appear
 * in the array.
 *
 * @returns an FIR filter intialized with the coefficients in file provided
 */
- (instancetype)initWithFilters:(NSArray *)filters;
/*! @brief Adds an MBasicFilter with a type, sampling rate and frequency range to the filter.
 *
 * @param type the type of filter to add to the compound filter.
 * @param rate the sampling rate of the filter to add.
 * @param range the frequency range of the filter to add.
 *
 * @returns the filter instance that was added to the compound filter.
 */
- (MPKBasicFilter *)addFilterWithType:(MPKFilterType)type  samplingRate:(float)rate range:(MPKFrequencyRange)range;
/*! @brief Adds an MBasicFilter with a type, center frequency, sampling rate and Q factor to the filter.
 *
 * @param type the type of filter to add to the compound filter.
 * @param centerFrequency the center frequency of the filter to add
 * @param rate the sampling rate of the filter to add
 * @param Q the Q factor of the filter to add
 *
 * @returns the filter instance that was added to the compound filter.
 */
- (MPKBasicFilter *)addFilterWithType:(MPKFilterType)type
                    centerFrequency:(float)centerFrequency
                       samplingRate:(float)rate qFactor:(float)Q;
/*! @brief Adds a filter to the end of the compound filter.
 *
 * @param filter the filter to add.
 */
- (void)addFilter:(id<MPKFilter>)filter;
/*! @brief Removes a filter from the compound filter.
 *
 * @param filter the filter to remove.
 */
- (void)removeFilter:(id<MPKFilter>)filter;
/*! @brief An array of filters that make up the filter chain
 *
 * @returns an array of MPKFilter objects.
 */
- (NSArray *)filters;
@end
/*! @brief A fast filter that adapatively removes noise from signal without the use of convolution.
 *  @attention Although this filter is several times faster than the MPKBasicFilter it's impact on data quality may be significant. Unlike 
 * the MPKBasicFilter, this filter does not pass and attenuate frequencies based on a range or center frequency you provide to it. 
 */
@interface MPKFastFilter : NSObject<NSCopying,MPKFilter>
/*! @brief Radial distance damping coefficient.
 * Defaults to 0.975.
 */
@property (nonatomic,assign) float m0;
/*! @brief Distortion smoothing coefficient.
 * Defaults to 0.9
 */
@property (nonatomic,assign) float m1;
@end

/*! @brief A finite impulse response filter.
 *
 *
 */
@interface MPKFIRFilter : NSObject<MPKFilter>
/*! @brief The file path containing the coefficients used to initialize the filter
 */
@property (nonatomic,strong,readonly) NSString * filePath;
/*! @brief Intitializes the FIR filter with a file containing the coefficients for the filter
 *
 * @param file the path to file containing the coefficients
 *
 * @returns an FIR filter intialized with the coefficients in file provided
 */
- (id)initWithFilePath:(NSString *)file;
@end
