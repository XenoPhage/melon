//
//  MPKDeviceHandle.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 6/23/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MPKDefines.h"


@class MPKSignalStream;




/// @brief A class used for representing devices that provides an interface for all melon hardware types (bluetooth, usb, wifi, etc). Currently only bluetooth is available.
/**
 *
 *
 **/
@interface MPKDeviceHandle : NSObject
/// @brief The estimated distance between the connecting device and the peripheral device.
/*
 * This value is not guarenteed to be accurate and should only be used as a hint.
 */
@property (nonatomic,assign,readonly) double distance;
/// @brief The connection status of the device.
/*
 * @see MPKDeviceConnectionStatus
 */
@property (nonatomic,assign,readonly) MPKDeviceStatus status;
/// @brief The manufactures name for the device
/*
 *
 */
@property (nonatomic,strong,readonly) NSString * name;
/// @brief A custom name for the device. This value is persistent between connections of the device.
/*
 * Use this property to let programs set custom names for devices. An example would be allowing a user
 * to change the name of a device in your ap.
 */
@property (nonatomic,copy) NSString * manualName;
/// @brief A persistent identifier for the device that is unique only to the machine requesting the connection.
/*
 */
@property (nonatomic,strong,readonly) NSString * identifier;

/// @brief A serial number for the device.
/*
 * @attention This value is universally unique.
 */
@property (nonatomic,strong,readonly) NSString * hardwareIdentifier;
/// @brief The RSSI(Received Signal Strength Indication) value of the device.
/*
 * This value is helpful in determining how close a device is.
 */
@property (nonatomic,strong,readonly) NSNumber * RSSI;
/// @brief The battery level of the device on a 0 to 1 scale where 1 is fully charged.
/*
 * This property is only available for devices that are connected.
 */
@property (nonatomic,strong,readonly) NSNumber * batteryLevel;
/// @brief Determine if the headband is charging.
/*
 *
 */
@property (nonatomic,assign,readonly,getter=isCharging) BOOL charging;

/// @brief Determine if the headband button is being pressed.
/*
 *
 */
@property (nonatomic,assign,readonly,getter=isMainButtonPressed) BOOL mainButtonPressed;
/// @brief Determine if the headband is streaming.
/*
 *
 */
@property (nonatomic,assign,readonly,getter=isStreaming) BOOL streaming;
/// @brief The signal stream used to process data from device.
/*
 * @discussion To process data from the device add your data processing outputs (i.e MPKSignalAnalyzer) to this 
 * stream to recieve data from this device while it is streaming
 * @attention It is safe to add/remove outputs while the device is already streaming.
 * @return The stream for the device.
 */
- (MPKSignalStream *)stream;
/// @brief Attempts to connect the device.
/*
 * @discussion This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager).
 * This is the same as using -connectWithHandler: with a nil handler parameter.
 */
- (void)connect;

/// @brief Attempts to connect the device and calls a callback handler with any errors.
/*
 * @discussion This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager)
 
 * @attention MPKBluetoothManager update handlers will still be called when using this method.
 */
- (void)connectWithHandler:(void(^)(MPKDeviceHandle * device, NSError * err))handler;

/// @brief Disconnects the device.
/*
 * @discussion This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager)
 */
- (void)disconnect;

/// @brief Disconnects the device and calls a callback handler with any errors.
/*
 * @attention MPKBluetoothManager update handlers will still be called when using this method.
 * @attention This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager)
 */
- (void)disconnectWithHandler:(void(^)(MPKDeviceHandle * device, NSError * err))handler;

/// @brief Powers down the device
/*
 * @attention This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager)
 */
- (void)powerDown;
/// @brief Attempts to start streaming the device.
/*
 * @discussion This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager)
 */
- (void)startStreaming;
/// @brief Stops streaming the device.
/*
 * @attention This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager)
 */
- (void)stopStreaming;
/// @brief Disconnects and tells the MPKBluetoothManager to remove any persistent data associated with this device.
/*
 * @attention This method returns immediately and may not immediately change any properties on the device handle.
 * the device handle should be evaluated in an update handler (see MPKBluetoothManager)
 */
- (void)forgetDevice;

/// @brief Disconnects the device if no requests to stream data have been recieved after period of time.
/*
 * 
 */
- (void)disconnectIfInactiveAfterDelay:(NSTimeInterval)delay;
/// @brief Cancels any disconnection requests scheduled with disconnectIfInactiveAfterDelay.
/*
 *
 */
- (void)cancelInactivityDisconnectionRequests;
 



@end

 
