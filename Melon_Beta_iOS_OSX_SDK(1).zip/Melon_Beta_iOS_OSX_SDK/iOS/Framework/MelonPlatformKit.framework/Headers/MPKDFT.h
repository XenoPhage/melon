//
//  MPKDFTResult.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 2/8/15.
//  Copyright (c) 2015 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MPKFloatBuffer;
/*! @brief Contains the results of the FFT performed by MPKSignalAnalyzer 
 *instances.
 *
 */
@interface MPKDFT : NSObject<NSCopying,NSCoding>
/*! @brief The amplitude values calculated from the signal FFT was performed on
 *
 */
@property (nonatomic,strong,readonly) MPKFloatBuffer * amplitude;
/*! @brief The frequency values calculated from the signal FFT was performed on
 * These are aligned with the -amplitude MPKFloatBuffer
 */
@property (nonatomic,strong,readonly) MPKFloatBuffer * frequencies;
/*! @brief The DCOffset of the signal
 *
 */
@property (nonatomic,strong,readonly) NSNumber * DCOffset;


@end
