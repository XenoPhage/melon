//
//  MBluetoothManager.h
//  MelonPlatformKit
//
//  Created by Eric L on 4/15/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
#if TARGET_OS_IPHONE
#import <CoreBluetooth/CoreBluetooth.h>
#elif TARGET_OS_MAC
#import <IOBluetooth/IOBluetooth.h>
#endif
#import "MPKDefines.h"
#import "MPKDeviceHandle.h"
//#import "MPKDeviceProximityContext.h"


extern NSString * const MPKBluetoothManagerChangedStateNotification;
extern NSString * const MPKBluetoothManagerChangedSearchingStateNotification;


typedef NSInteger MPKBluetoothManagerState;
/*! @brief Used to manage bluetooth low energy connections to melon devices.
 *
 * Use of this class to connect to the headband is preferred over using Core Bluetooth directly.
 */
@interface MPKBluetoothManager : NSObject
/*! @brief A shared Singleton instance of MBluetoothManager. You should always use this and never allocate your own.
 *
 * @return An instance of MBluetoothManager setup for use with melon devices.
 */
+ (MPKBluetoothManager *)sharedManager;

/*! @brief The state of the bluetooth on localhost.
 *
 * This property is identical to the CBCentralManager's state property.
 *
 * From CBCentralManager:
 *
 *  @constant CBCentralManagerStateUnknown       State unknown, update imminent.<br>
 *  @constant CBCentralManagerStateResetting     The connection with the system service was momentarily lost, update imminent.<br>
 *  @constant CBCentralManagerStateUnsupported   The platform doesn't support the Bluetooth Low Energy Central/Client role.<br>
 *  @constant CBCentralManagerStateUnauthorized  The application is not authorized to use the Bluetooth Low Energy Central/Client role.<br>
 *  @constant CBCentralManagerStatePoweredOff    Bluetooth is currently powered off.<br>
 *  @constant CBCentralManagerStatePoweredOn     Bluetooth is currently powered on and available to use.<br>
 *
 * @return The state of the bluetooth on localhost.
 */


@property(nonatomic,assign,readonly) MPKBluetoothManagerState state;

/*! @brief Specifies whether or not the the bluetooth manager should discard powered off or unavailable devices.
 *
 * @return A boolean value that indicates whether or not the the bluetooth manager should discard powered off or unavailable devices.
 */
@property (nonatomic,assign) BOOL shouldDiscardUnavailableDevices;

/*! @brief Whether or not the manager is currently looking for melon compatible devices.
 *
 * @return A boolean value that indicates whether or not the manager is actively scanning for devices.
 */
@property (nonatomic,assign,readonly,getter = isSearchingForDevices) BOOL searchingForDevices;


//
///*! @brief Sets whether previously connected devices are connected when discovered.
// *
// * @attention Setting this value to YES will cause the SDK to automatically connect to the last previously connected
// * device when it is discovered while a search is active.
// */
//@property (nonatomic,assign,getter=isAutoConnectEnabled) BOOL autoConnectEnabled;

/*! @brief The name, identifier, hardwarIdenfitifer and manualName of the auto connected device.
 *
 * @return An NSDictionary representing the device that is auto connected by the SDK when discovered or nil if none is set.
 * @attention The return value of this property is not affected by autoConnectEnabled.
 */
@property (nonatomic,strong) NSDictionary * preferredDeviceInfo;


/// @brief Asynchronously retrieves the currently connected device or nil if no device exists.
/*
 */
- (void)retrieveConnectedDevice:(void(^)(MPKDeviceHandle * device))block;

/*! @brief The currently connected device.
 *
 * @return An MPKDeviceHandle for the currently connected device.
 */
- (MPKDeviceHandle *)connectedDevice;


/*! @brief All devices the bluetooth manager is aware of, this may include devices that have been discovered and powered
 * off.
 *
 * @return An array of MPKDeviceHandle's
 */
- (NSArray *)availableDevices;

/*! @brief Starts searching for melon headband devices.
 *
 * Calling this method will start searching for connectable headband devices.
 *
 * @attention Once you have found the device you wish to connect to, you should call stopSearchingForDevices.
 */
- (void)startSearchingForDevices;

/*! @brief Stops the search for melon headband devices.
 *
 * Calling this method will stop any active search for headband devices.
 *
 * @attention This method is called automatically upon connecting to a device.
 *
 */
- (void)stopSearchingForDevices;
/*! @brief Stops the search for melon headband devices after a delay
 *
 *
 *
 *
 */
- (void)stopSearchingForDevicesAfterDelay:(NSTimeInterval)delay;
/*! @brief Disconnects every headband and stops any device search that is currently running.
 *
 * Calling this method will disconnect all bluetooth devices and stop any device searches.
 *
 *
 */

- (void)terminateAllConnections;
/*! @brief Allows you to toggle specific updates that cause your update handler to be invoked.
 *
 * @param enabled set whether or not the update reason is enabled
 * @param reasonMask an individual (or maske of) MPKDeviceUpdate reason(s) you would like to enable or disable
 * @param handlerKey the key used to identify the update handler.
 *
 * @attention It is safe to call this method before calling setUpdateHandler:forKey:
 *
 */
- (void)setNotificationsEnabled:(BOOL)enabled
                     forUpdates:(MPKDeviceUpdate)reasonMask
                         forKey:(NSString *)handlerKey;

/*! @brief Allows you to set which updates will cause your update handler to be invoked.
 * This method will clear any previous update reasons for this key.
 *
 *
 * @param reasonMask an individual (or mask of) MPKDeviceUpdate reason(s) you would like to enable or disable. When 0 this will disable notifications.
 * @param handlerKey the key used to identify the update handler.
 *
 * @attention It is safe to call this method before calling setUpdateHandler:forKey:
 *
 */
- (void)setUpdateNotificationReasons:(MPKDeviceUpdate)reasonMask
                              forKey:(NSString *)handlerKey;


/// @brief Adds a block that is called everytime a devices status updated.
/**
 *
 * Update handlers are called for every time a device update occurs. The block will be invoked with the device the update
 * occured on and the reason the update happened.
 *
 * @param block the block to be called when an update occurs. Pass nil to remove a block for the key provided.
 * @param key The key to associate the update handler block with. Must not be nil.
 *
 * @attention If a handler is already associated with the key provided, it will be replaced by the value of the block
 * parameter.
 **/
- (void)setUpdateHandler:(void(^)(MPKDeviceUpdate,MPKDeviceHandle *))block
                  forKey:(NSString *)key;

/// @brief Removes the update handler associated with the key.
/**
 * This method is identical to [manager setUpdateHandler:nil forKey:key]
 **/
- (void)removeUpdateHandlerForKey:(NSString *)key;
/// @brief Terminates any existing connections, scans or updates.
/**
 * Call this method to reset the bluetooth mananger to its initial state. This will not remove auto connected
 * device data.
 */
- (void)reset;
/// @brief Displays the default iOS bluetooth power alert if bluetooth is not powered on.
/**
 */
- (void)displayBluetoothPoweredOffAlertIfNeeded;
/// @brief Clears the auto connect device information.
/** @attention This will not disable auto connection.
 */
- (void)clearAutoConnectedDeviceInfo;
/// @brief Synchronously executes a block on the main thread with respect to the managers underlying serial queue.

/**
 *
 * Use this method to batch multiple operations involving MPKBluetoothManager or MPKDeviceHandle objects.
 * @discussion it is safe to call performSynchronousBlock and performAsynchronousBlock recurisively from the block.
 * @attention This method can only be used from the main thread.
 * @attention The MPKBluetoothManager and MPKDeviceHandle classes are thread safe, this method is an opt-in and may
 * yield small performance improvements during intialization routines (i.e viewDidLoad etc). Its use is not required.
 */
- (void)performSynchronousBlock:(void(^)(void))block;

/// @brief Asynchronously submits a block to execute on the main thread with respect to the managers underlying serial queue.

/**
 * Use this method to batch multiple operations.
 * @attention The MPKBluetoothManager and MPKDeviceHandle classes are thread safe, this method is an opt-in and may
 * yield small performance improvements during intialization routines (i.e viewDidLoad etc). Its use is not required.
 */
- (void)performAsynchronousBlock:(void(^)(void))block;


/// @brief Attemps to connect to the preffered device.
/*
 */
- (BOOL)attemptToConnectToPreferredDevice;


- (instancetype)init __attribute__((unavailable("Multiple instances of MPKBluetoothManager is unsupported")));

@end
/// @brief These methods invoke the MPKBluetoothManager methods with the same name.
/*
 */
@interface MPKDeviceHandle(MPKDeviceHandleManagerConvenienceExtensions)
/// @brief Asynchronously retrieves the currently connected device or nil if no device exists.
/*
 */
+ (void)retrieveConnectedDevice:(void(^)(MPKDeviceHandle * device))block;

/// @brief Returns the currently connected device or nil if no device exists.
/*
 */
+ (MPKDeviceHandle *)connectedDevice;
/// @brief Returns all available devices that have been discovered.
/*
 * @attention If an auto connectable device exists it will always be returned, even if the device has not been rediscovered.
 */
+ (NSArray *)availableDevices;
/// @brief Returns an NSDictionary that contains identifying info about the device.
/*
 * This dictionary may be used to set the preffered device on the MPKBluetoothManager.
 */
- (NSDictionary *)dictionaryRepresentation;

@end

@interface NSDictionary(MPKDeviceHandleAutoConnectInfoExtensions)
- (NSString *)identifier;
- (NSString *)name;
- (NSString *)hardwareIdentifier;
- (NSString *)manualName;
@end
