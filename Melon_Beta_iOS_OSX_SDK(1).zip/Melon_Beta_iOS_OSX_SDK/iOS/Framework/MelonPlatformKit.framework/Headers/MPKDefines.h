//
//  MPKDefines.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 6/12/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//
#import <Foundation/Foundation.h>
#ifndef __MPK_DEFINES__
#define __MPK_DEFINES__

/** @file MPKDefines.h */
extern NSString * const MPKErrorDomain;

//typedef mFloat ;
typedef NS_ENUM (NSInteger, MPKError){
    MPKErrorUnknown            = 1,
    MPKErrorDeviceWriteFailed  = 2,
    MPKErrorOperationCancelled = 3,
    MPKErrorOperationFailed    = 4,
    MPKErrorOperationTimedOut  = 5,
    MPKErrorDeviceHardwareInconsistency  = 6,
};

typedef NS_ENUM (NSInteger, MPKErrorSubtype){
    MPKErrorSubtypeNoServices,
};

 

/// @brief Available types for classes conforming to MPKDataProcessor
/**
 * These types specify what the data processor does.
 **/
typedef NS_OPTIONS(NSUInteger, MPKDataProcesserType){
    /// @brief The MPKDataProcessor performs FFT.
    /**
     *
     **/
    MPKDataProcesserTypeFFT = (1UL << 0),
    /// @brief The MPKDataProcessor calculates a focus score based on either, neural, occular or other activity.
    /**
     *
     **/
    MPKDataProcesserTypeFocusAlgorithm = (1UL << 1),
    /// @brief The MPKDataProcessor validates signal activity.
    /**
     *
     **/
    MPKDataProcesserTypeSignalValidation = (1UL << 2),
    /// @brief The MPKDataProcessor has no specific type.
    /**
     * Use this to group data processors together that don't fall into the other categories.
     **/
    MPKDataProcesserTypeOther = (1UL << 3),
};

extern const MPKDataProcesserType MPKDataProcesserTypeAll;
extern const NSUInteger MPKDefaultSamplingRate;

/// @brief Specifies the status of data stored in an MPKChannelDescription
/**
 * An example of this would be the status of the FFT.
 **/
typedef NS_ENUM(NSUInteger, MPKChannelAttributeStatus) {
    /// @brief The status is unknown.
    /**
     * This may occur right when the device has started streaming and hasnt finished calibrating yet.
     **/
    MPKChannelAttributeStatusUnknown = 0,
    /// @brief The status is valid.
    /**
     *
     **/
    MPKChannelAttributeStatusValid = (1U<<1),
    /// @brief The status is invalid.
    /**
     *
     **/
    MPKChannelAttributeStatusInvalid = (1U<<2),
    /// @brief The status is unknown.
    /**
     * This may occur right when the device has started streaming and hasnt finished calibrating yet.
     **/
    MPKChannelAttributeStatusCalibrating = MPKChannelAttributeStatusUnknown,
    
};

/// @brief Specifies how MPKSignalAnalyzer treat poor signal detection.
/**
 * When MPKSignalAnalyzers detect poor signal (if detection is enabled), the analyzer will enter "idle state."
 * When in idle state some data processors may be skipped. These values specify how the analyzer is allowed to transition
 * between idle and non idle states.
 *
 **/
typedef NS_OPTIONS(NSUInteger, MPKSignalAnalyzerIdleStateTransition) {
    /// @brief The analyzer may enter idle state.
    /**
     *
     **/
    MPKSignalAnalyzerIdleStateTransitionEnterIdle = (1U<<0),
    /// @brief The analyzer may enter idle state.
    /**
     *
     **/
    MPKSignalAnalyzerIdleStateTransitionLeaveIdle = (1U<<1),
};

/*! @brief The types of MPKSignalAnalyzers
 **/
typedef NS_ENUM(NSUInteger, MPKSignalAnalyzerType) {
    /// @brief The MPKSignalAnalyzer processes data from both electrodes.
    /**
     * @attention Only stereo should be used for now.
     **/
    MPKSignalAnalyzerTypeStereo=0,
    /// @brief The MPKSignalAnalyzer processes data from one electrode.
    /**
     *
     **/
    MPKSignalAnalyzerTypeMono=1,
};

/*! @brief  Possible device statuses.
 * These determine the status the device is in.
 **/
typedef NS_ENUM(NSUInteger, MPKDeviceStatus) {
    /// @brief The device status cannot be determined right now.
    /**
     *
     **/
    MPKDeviceStatusUnknown        = 0,
    /// @brief The device has been discovered from a current or past search, but not yet connected.
    /**
     *
     **/
    MPKDeviceStatusDiscovered     = 1,
    /// @brief The device is attempting to connect.
    /**
     * @attention Bluetooth LE connection requests do not timeout unless an error occurs. Connections requests made to
     * out of range or powered down devices will automatically connect once the device becomes available unless they
     * are cancelled.
     **/
    MPKDeviceStatusConnecting     = 2,
    /// @brief The device is connected and its services have been discovered.
    /**
     *  The SDK does not consider a device fully connected until all services on the BLE device are discovered.
     *
     **/
    
    MPKDeviceStatusConnected      = 3,
    /// @brief The device is powered off.
    /**
     * The SDK only assumes the power state of device if
     * A. The device was powered off from the SDK
     * B. The device notified the SDK that it will power off while it was connected.
     *
     **/
    MPKDeviceStatusPoweredOff     = 4,
};



/*!@brief Reasons a for a device update.
 * These values indicate why a device update block was executeed.
 **/

typedef NS_OPTIONS(NSUInteger, MPKDeviceUpdate) {
    
    /// @brief A device was sucessfully connected.
    /**
     *
     **/
    MPKDeviceUpdateDidConnect = (1UL<<0),
    
    /// @brief A device is attempting to connect.
    /**
     *
     **/
    MPKDeviceUpdateWillConnect = (1UL<<1),
    
    /// @brief A device was disconnected.
    /**
     *
     **/
    MPKDeviceUpdateDidDisconnect = (1UL<<2),
    
    /// @brief A changed it's charging state.
    /**
     *
     **/
    MPKDeviceUpdateChargingStateChanged = (1UL<<3),
    
    /// @brief A device(s) was discovered.
    /**
     *
     **/
    MPKDeviceUpdateDiscovered = (1UL<<4),
    
    /// @brief A device started streaming data.
    /**
     *
     **/
    MPKDeviceUpdateStartedStreaming = (1UL<<5),
    
    /// @brief A device stopped streaming data.
    /**
     *
     **/
    MPKDeviceUpdateStoppedStreaming = (1UL<<6),
    
    /// @brief Indicates the device is powering off
    /**
     *
     **/
    MPKDeviceUpdateWillPowerOff = (1UL<<7),
    
    /// @brief Indicates the device did power off
    /**
     *
     **/
    MPKDeviceUpdateDidPowerOff = (1UL<<8),
    
    /// @brief Indicates the devices battery value updated.
    /**
     *
     **/
    MPKDeviceUpdateBatteryChanged = (1UL<<9),
    
    /// @brief Indicates the device is about to start streaming.
    /**
     *
     **/
    MPKDeviceUpdateWillStartStreaming = (1UL<<10),
    
    /// @brief Indicates the devices RSSI updated.
    /**
     * You will not recieve this notification by default, you must enable it using MPKBluetoothManager's
     * -setNotificationsEnabled:forUpdateReason:onHandlerForKey: method.
     **/
    MPKDeviceUpdateRSSIChanged = (1UL<<11),
    
    /// @brief Indicates the device's power button was pressed.
    /**
     * You will not recieve this notification by default, you must enable it using MPKBluetoothManager's
     * -setNotificationsEnabled:forUpdateReason:onHandlerForKey: method.
     **/
    MPKDeviceUpdateMainButtonPressed=(1UL<<12),
    
    /// @brief Indicates the device's power button was released
    /**
     * You will not recieve this notification by default, you must enable it using MPKBluetoothManager's
     * -setNotificationsEnabled:forUpdateReason:onHandlerForKey: method.
     **/
    MPKDeviceUpdateMainButtonReleased=(1UL<<13),
    /// @brief A device has stopped being managed by the bluetooth manager.
    /**
     * This update occurs when the bluetooth manager removes a device from it's list of known devices.
     * This includes, discovered, powered off and connected devices. If this update is recieved while
     * the bluetooth manager is scanning for devices and the device is discoverable,
     * the device may generate a discovery update.
     **/
    MPKDeviceUpdateDidRemove = (1UL<<14),
    
    
};

/// @brief A mask specifying all update reasons.
/**
 * Use with -setNotificationsEnabled:forUpdateReason:onHandlerForKey: to enable or disable all notifications.
 **/
extern const MPKDeviceUpdate MPKDeviceUpdateAllReasons;
/// @brief A mask specifying the default update reasons.
/**
 * Use with -setNotificationsEnabled:forUpdateReason:onHandlerForKey: to enable or disable all notifications.
 **/
extern const MPKDeviceUpdate MPKDeviceUpdateDefaultReasons;
/*! @brief Filter tpes for the MPKBasicFilter class
 *
 */
typedef NS_ENUM(NSUInteger, MPKFilterType) {
    /*! @brief Specifies that the filter is a notch filter.
     * This filter type does not use a frequency range.
     */
    MPKFilterTypeNotch=0,
    /*! @brief Specifies that the filter is a bandpass filter.
     * This filter uses a frequency range.
     */
    MPKFilterTypeBandpass=1,
    /*! @brief Specifies that the filter is a low pass filter.
     * This filter type does not use a frequency range.
     */
    MPKFilterTypeLowPass=2,
    /*! @brief Specifies that the filter is a high pass filter.
     * This filter type does not use a frequency range.
     */
    MPKFilterTypeHighPass=3,
    /*! @brief Specifies that the filter is a band pass filter where the Q factor is equal to the peak frequency.
     *
     */
    MPKFilterTypeBandpassQPeak=4,
    /*! @brief Specifies that the filter is a all pass filter.
     * This filter type does not use a frequency range.
     */
    MPKFilterTypeAllPass = 5,
};


#define MPKNullFrequencyRange MPKFrequencyRangeMake(NAN, NAN)
/*! @brief A struct defining a frequency range in Hertz
 *
 */
typedef struct MPKFrequencyRange {
    float min;
    float max;
} MPKFrequencyRange;
/*! @brief Creates a MPKFrequencyRange struct
 *
 *@param min The min frequency in Hertz
 *@param max The max frequency in Hertz
 */

NS_INLINE MPKFrequencyRange MPKFrequencyRangeMake(float min,float max) {
    MPKFrequencyRange r;
    r.min = min;
    r.max = max;
    return r;
};

NS_INLINE BOOL MPKFrequencyRangeEquals(MPKFrequencyRange r1,MPKFrequencyRange r2) {
    if (isnan(r1.min) && isnan(r2.min) && isnan(r1.max) && isnan(r2.max))return true;
    ;
    return (fabsf((r1.min) - (r2.min)) < FLT_EPSILON) && (fabsf((r1.max) - (r2.max)) < FLT_EPSILON);
};



#endif
