//
//  MPKChannelSet.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 9/3/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MPKChannelDescription.h"
/*! @brief Contains the MPKChannelDescription's for all channels processed by an MPKSignalAnalyzer.
 *
 */
@interface MPKChannelSet : NSObject<NSCoding,NSCopying>
/*! @brief The MPKChannelDescription for data coming from the leftChannel.
 *
 */
@property (nonatomic,strong,readonly) MPKChannelDescription * leftChannel;
/*! @brief The MPKChannelDescription for data coming from the rightChannel.
 *
 */
@property (nonatomic,strong,readonly) MPKChannelDescription * rightChannel;
/*! @brief The MPKChannelDescription used by default MPKDataProcessors.
 * 
 */
@property (nonatomic,strong,readonly) MPKChannelDescription * dominantChannel;
/*! @brief Recursivly copies the MPKChannelSet and it's channel description without preserving
 * any collections types.
 * Any properties in the MPKChannelDescription that are collection type will be nil in the copy. 
 * This is useful when you need to store many MPKChannelSet's in memory.
 */
- (instancetype)copyWithoutPreservingCollections;
/*! @brief Recursivly copies the MPKChannelSet and it's channel description without preserving
 * any collections types with the exception of collections containing the most recent sample data 
 * used for analysis.
 * Any properties in the MPKChannelDescription that are collection type will be nil in the copy.
 * This is useful when you need to store many MPKChannelSet's in memory.
 */
- (instancetype)copyPreservingAnalysisResultsOnly;
/*! @brief Determine if the signal was "idle" when this channel set was generated.
 */
- (BOOL)isIdle;

@end
