//
//  MEEGStream.h
//  Melon Platform
//
//  Created by Eric L on 3/19/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MPKAudioCapture;
#if TARGET_OS_IPHONE
#import <CoreBluetooth/CoreBluetooth.h>
#elif TARGET_OS_MAC
#import <IOBluetooth/IOBluetooth.h>

#endif
#import "MPKBluetoothManager.h"
@class MPKSignalAnalyzer;
@class MPKDeviceHandle;
@class MPKSignalStream;




/*! @brief Specifies protocols that custom output objects can implement to process data from the signal stream
 *
 *  You can create your own class and have it conform to MPKSignalStreamOutput or you can use the already provided classes
 * MHeadbandSignalAnalyzer (typically used for the default 2-channel Melon headband) or MPKSignalAnalyzer (used as a generic buffer)
 * @attention All methods will be invoked on the signal stream's queue. The callbacks from the delegate DO NOT affect outputs.
 */
@protocol MPKSignalStreamOutput <NSObject>
@optional

/*! @brief Invoked immediately prior to an output being removed from the stream.
 * You can use this for any clean up or releasing references to the stream your output may have.
 * @param stream The stream that owns the output.
 */
- (void)willBeRemovedFromStream:(MPKSignalStream *)stream;

/*! @brief Invoked when the stream first recieves data after being opened.
 * This is a good place to setup any timers or threads that should only run while the stream is recieving data.
 * @param stream The stream that owns the output.
 */
- (void)streamDidBeginStreaming:(MPKSignalStream *)stream;

/*! @brief Invoked when the stream opens
 *
 * @param stream The stream that owns the output.
 */
- (void)streamDidOpen:(MPKSignalStream *)stream;


/*! @brief Invoked when the stream closes
 *
 * @param stream The stream that owns the output.
 */
- (void)streamDidClose:(MPKSignalStream *)stream;



/*! @brief Invoked when the signal stream decodes its recieved data into raw voltage.
 *
 * @param stream the stream that output the values
 * @param values An array of floats containing sample values of each channel in volts;
 * @param moreComing When YES, indicates that the stream analyzer is delivering batched samples and that this method will be called multiple times within a single
 * runloop cycle. It is best to signal threads, start/stop timers, etc etc when moreComing == NO.
 */
- (void)stream:(MPKSignalStream *)stream
didRecieveValues:(float[2])values
     timestamp:(double)timestamp
    moreComing:(BOOL)moreComing;






/*! @brief Specifies the priority of this output.
 *  You may want some outputs to process data before or after other outputs. By specifying a lower number you guarantee your output will have its methods called before outputs with higher numbers.
 
 * @param stream The stream that contains the output
 */
- (NSUInteger)outputPriorityForStream:(MPKSignalStream *)stream;


@end



/// @brief Streams data from Melon hardware.
/**
 *  Use this class to setup and manage data transfer to and from Melon Hardware.
 *
 * @attention You usually should never manually create an MPKSignalStream. Most classes that require them (such as the MPKDeviceHandle) will
 * create and manage them for you.
 
 *
 **/
@interface MPKSignalStream : NSObject

/// @brief Enables or disables latency correction.
/**
 * When latency correction is enabled the signal stream attempts to synchronize incoming data packets with the expected time they would be delivered based on the devices 
 * sampling rate.
 *
 *
 * The default is NO.
 **/
@property (nonatomic,assign) BOOL latencyCorrectionEnabled;
/// @brief The packet latency between incoming data packets
/**
 * The time is measured in milliseconds.
 **/
@property (nonatomic,assign,readonly) double packetLatency;
/// @brief Deterimine if the stream is open or not.
/**
 *
 **/
@property (nonatomic,assign,readonly,getter=isOpened) BOOL opened;

/// @brief Used to add an output to the stream.
/**
 *  Use this method to add an output to the stream. This method is thread safe
 **/
- (void)addOutput:(id<MPKSignalStreamOutput>)output;
/// @brief Used to remove an output from the stream.
/**
 *  Use this method to remove an output from the stream. This method is thread safe
 **/
- (void)removeOutput:(id<MPKSignalStreamOutput>)output;
/// @brief Used to remove multiple outputs from the stream
/**
 *  Use this method to remove multiple outputs from the stream. This method is thread safe and calls
 **/
- (void)removeOutputs:(NSArray *)outputs;
/// @brief Used to remove all outputs from the stream
/**
 *  Use this method to remove all outputs from the stream. This method is thread safe
 **/
- (void)removeAllOutputs;
/// @brief An array of outputs added to the signal stream.
/**
 * @returns An array containing the outputs for the signal stream
 **/
- (NSArray *)allOutputs;


@end



