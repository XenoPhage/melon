//
//  MPKBlockDataProcessor.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 10/25/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MPKDataProcessor.h"
/// @brief A block based MPKDataProcessor class
/**
 * You can use this class to implement a block based MPKDataProcessor. 
 * All methods defined in the MPKDataProcessor call their MPKBlockDataProcessor block equivalents
 **/
@interface MPKBlockDataProcessor : NSObject<MPKDataProcessor>
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) NSInteger(^resetWithAnalyzerBlock)(MPKBlockDataProcessor * proc,MPKSignalAnalyzer *buffer);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) NSInteger(^dataProcessorPriorityBlock)(MPKBlockDataProcessor * proc);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^supportsIdleSignalRecognitionBlock)(MPKBlockDataProcessor * proc);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^idleSignalRecognitionPossibleBlock)(MPKBlockDataProcessor * proc);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^idleSignalRecognizedBlock)(MPKBlockDataProcessor * proc);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^requiresUpdateEveryCycleBlock)(MPKBlockDataProcessor * proc);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^requiresUpdateToApplyToAllChannelsBlock)(MPKBlockDataProcessor * proc);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) MPKDataProcesserType(^dataProcessorTypeBlock)(MPKBlockDataProcessor * proc);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^supportsProcessingOfChannelBlock)(MPKBlockDataProcessor * proc,NSUInteger channel);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^prepareToUpdateChannelDescriptionBlock)(MPKBlockDataProcessor * proc,MPKChannelDescription * channel);
/*! @see MPKDataProcessor
 */
@property (nonatomic,copy) BOOL(^updateChannelDescriptionBlock)(MPKBlockDataProcessor * proc,MPKChannelDescription * channel);

@end
