//
//  MPKAPI.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 11/25/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
/// @brief The core class used to initialize the SDK.
/**
 * All programs using the MelonPlatformKit must call either +handleApplicationLaunchWithAPIKey: or 
 * +handleApplicationLaunch
 * @attention A key is not required to use the SDK, if you do not have a valid key use handleApplicationLaunch. 
 * Using an invalid key may caused undefined behavior.
 **/
@interface MelonPlatformKit : NSObject
/// @brief Sets the frequency of surrounding electrical noise that the SDK should filter out.
/**
 * This value is generally 50Hz or 60Hz.
 * @attention If possible this value is determined for you when one of the handleApplicationLaunch methods are called.
 */
+ (void)setDefaultInterferenceFrequency:(NSUInteger)frequency;
/// @brief Gets the frequency of surrounding electrical noise that the SDK should filter out.
/**
 *
 */
+ (NSUInteger)defaultInterferenceFrequency;
/// @brief Attempts to find and store the +defaultInterferenceFrequency
/**
 * This method looks up the current devices locale and determines the frequency based on the country they are in. 
 * @attention Japan uses both 60 and 50hz.
 * @param complete a blcok used to
 */
+ (void)detectInterferenceUsingFrequencyCurrentLocale:(void(^)(NSUInteger frequency, BOOL suceeded))complete;
/// @brief Initializes the SDK with an API key.
/**
 * This method must be called before the SDK is used at all. In iOS/OS X it is usually called from your application 
 * delegates launch notification methods. It is safe to call this from main() for GUI-less programs.
 @attention A key is not required to use the SDK, if you do not have a valid key use handleApplicationLaunch.
 * Using an invalid key may caused undefined behavior.
 */
+ (void)handleApplicationLaunchWithAPIKey:(NSString *)apiKey;
/// @brief Initializes the SDK without an API key.
/**
 * This method must be called before the SDK is used at all. In iOS/OS X it is usually called from your application
 * delegates launch notification methods. It is safe to call this from main() for GUI-less programs.
 @attention A key is not required to use the SDK, if you do not have a valid key use handleApplicationLaunch.
 *
 */
+ (void)handleApplicationLaunch;
/// @brief If one was used, returns the API key used to initialize the SDK.
/***
 *
 **/
+ (NSString *)APIKey;
 
@end
 