//
//  MHeadbandSignalAnalyzer.h
//  MelonPlatformKit
//
//  Created by Eric L on 6/6/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "MPKSignalStream.h"
#import "MPKDefines.h"

@class MPKSignalStream;
@class MPKChannelSet;
@class MPKSignalAnalyzer;

@protocol MPKDataProcessor;
@protocol MPKFilter;
@protocol MPKSignalAnalyzerOutput;
@protocol MPKSignalAnalyzerDelegate;
/*! @brief class A that processes data from an MPKSignalStream.
 *
 *
 * This class is the default class used to process data from MPKSignalStreams.
 *
 * Processing is handled by adding objects conforming to the MPKDataProcessor 
 * protocol to the buffer.
 * There are several default MPKDataProcessor classes already added to the buffer.
 * The default processors do the following:
 * - Perform FFT
 * - Validate signal
 * - Calculate focus. 
 *
 * These defaults can be enabled or disabled using the enabledDataProcesserTypes property.
 * You should never remove default data processors from the buffer.
 *
 */
 
@interface MPKSignalAnalyzer : NSObject <MPKSignalStreamOutput>
/*! @brief The delegate for the signal stream buffer.
 */
@property (nonatomic,weak) id <MPKSignalAnalyzerDelegate> delegate;
/*! @brief When signal validation is enabled, this mask allows you to specify what transitions the validator can make to the.
 * For example if you specify, MPKSignalAnalyzerIdleStateTransitionEnterIdle only, the analyzer can only enter idle state, it cannot leave it.
 *
 */
@property (nonatomic,assign) MPKSignalAnalyzerIdleStateTransition allowedIdleTransitions;
/*! @brief Used to enable or disable the buffer. When enabled == NO, the analyzer ignores all 
 * incoming data.
 *
 */
@property (nonatomic,assign,getter = isEnabled) BOOL enabled;
/*! @brief Used to enable or disable the callback of output methods. When outputsAreEnabled == NO, 
 *the analyzer will not invoke the methods of its callbacks
 *
 */
@property (nonatomic,assign) BOOL outputsAreEnabled;

/*! @brief The types of data processors that are allowed to run on the left channel. Defaults to all.
 *
 * Use this value to disable or enable data processor types.
 * For example, if you're just graphing raw or filtered data, you may not need a focus score or 
 * signal validation.
 * @attention Most MPKDataProcesserTypes require FFT to be enabled and will enable it
 * implicitly.
 */
@property (nonatomic,assign) MPKDataProcesserType leftChannelEnabledDataProcesserTypes;

/*! @brief The types of data processors that are allowed to run on the right channel. Defaults to dsp validation and FFT.
 *
 * Use this value to disable or enable data processor types.
 * For example, if you're just graphing raw or filtered data, you may not need a focus score or
 * signal validation.
 * @attention Most MPKDataProcesserTypes require FFT to be enabled and will enable it
 * implicitly.
 */
@property (nonatomic,assign) MPKDataProcesserType rightChannelEnabledDataProcesserTypes;
/*! @brief The processing latency of the analyzer in microseconds.
 *  This value is calculated by measuring how long it takes to perform FFT, filter signal and run all data processors.
 *  Bluetooth latency is not taken into account.
 *
 */
@property (nonatomic,assign,readonly) NSUInteger latency;

/*! @brief The cpu usage (sampled every 25hz) that the processing thread of the analyzer is using.
 * This value is on a 0 to (host machine cores)x1000 scale where (host machine cores)x1000 is equal to 100% cpu usage.
 * For example, if -processingCPUUsage == 1500 on a machine with two cores, the real CPU usage would be 75% (1500/(1000.0x host machine cores))
 *
 *
 */
@property (nonatomic,assign,readonly) NSUInteger processingCPUUsage;

/*! @brief The size of the analyzer used to process the signal
 *
 * For optimal performance, this size should be at least 2 times  your sampling rate.
 */
@property (nonatomic,assign,readonly) NSUInteger bufferSize;

/*! @brief The sampling rate in Hertz that your data is processed at
 *
 * When processing data samples will be taken from the back of the analyzer (the most recent data) using this rate.  (i.e [signalBuffer
 * subarrayWithRange:NSMakeRange(signalBuffer.count-samplingRate,samplingRate)]
 *
 * @attention The default sampling rate is 250hz for Melon Headbands and should probably be left at that.
 */
@property (nonatomic,assign,readonly) NSUInteger samplingRate;


/*! @brief The rate stream analysis is performed as a fraction of your sampling rate.
 *
 * This should be a value from 0.0 to 1.0. Defaults to 0.01666666666667 (i.e if your sampling rate is 250hz, analysis is performed 
 * every 4 samples)
 * If you are using the default sampling rate of 250 it is safe to treat this value as a time interval in seconds. 
 *
 */
@property (nonatomic,assign) NSTimeInterval analysisRate;


/*! @brief Sets whether or not FFT is performed on filtered signal only.
 *
 * When this property is set to YES, raw signal will be ignored when performing FFT. 
 *
 */
@property (nonatomic,assign) BOOL performFFTOnFilteredSignalOnly;


/*! @brief The number of cycles the analyzer has completed
 *
 * A cycle is everytime 1 sampling rate's worth of data is processed.
 *
 */
@property (nonatomic,assign,readonly) NSUInteger cycles;

/*! @brief The signal stream that is being buffered.
 *
 * This is the stream the signal analyzer recieves its data from.
 */
@property (nonatomic,weak,readonly) MPKSignalStream * stream;

/*! @brief The result of the processed data from the most recent cycle.
 *
 */
@property (nonatomic,strong,readonly) MPKChannelSet * analysisResult;
/*! @brief The type of the signal stream buffer.
 *
 
 */

@property (nonatomic,assign,readonly) MPKSignalAnalyzerType type;




/*! @brief Initializes the analyzer with a size, sampling rate and type.
 *
 * @attention The initialize will not create a analyzer suitable for use with a melon headband unless you use the same
 * analyzer size, sampling rate and type as the object returned by +analyzer or +analyzerWithSize:.
 *
 * @param size The size of the buffer. Must be larger than the sampling rate.
 * @param rate The sampling rate in hertz to process the data at.
 * @param type The type of buffer. Either Stereo or Mono.
 
 */
- (instancetype)initWithBufferSize:(NSUInteger)size samplingRate:(NSUInteger)rate type:(MPKSignalAnalyzerType)type;
/*! @brief Initializes the analyzer with a sampling rate and type. This initializer will set the analyzer size to 4 times the 
 * sampling rate.
 *
 * @attention The initialize will not create a analyzer suitable for use with a melon headband unless you use the same
 * analyzer size, sampling rate and type as the object returned by +analyzer or +analyzerWithSize:.
 *
 * @param rate The sampling rate in hertz to process the data at.
 * @param type The type of buffer. Either Stereo or Mono.
 */
- (instancetype)initWithSamplingRate:(NSUInteger)rate type:(MPKSignalAnalyzerType)type;
/*! @brief Convience intitalizer for - (instancetype)initWithBufferSize:(NSUInteger)size samplingRate:(NSUInteger)rate type:
 * (MPKSignalAnalyzerType)type;
 *
 * @attention The initialize will not create a analyzer suitable for use with a melon headband unless you use the same
 * analyzer size, sampling rate and type as the object returned by +analyzer or +analyzerWithSize:.
 *
 * @param size The size of the buffer. Must be larger than the sampling rate.
 * @param rate The sampling rate in hertz to process the data at.
 * @param type The type of buffer. Either Stereo or Mono.
 */
+ (instancetype)analyzerWithSize:(NSUInteger)size samplingRate:(NSUInteger)rate  type:(MPKSignalAnalyzerType)type;
/*! @brief Convience intitalizer for - (instancetype)initWithSamplingRate:(NSUInteger)rate type:
 * (MPKSignalAnalyzerType)type;
 *
 * @attention The initialize will not create a analyzer suitable for use with a melon headband unless you use the same
 * analyzer size, sampling rate and type as the object returned by +analyzer or +analyzerWithSize:.
 *
 * @param rate The sampling rate in hertz to process the data at.
 * @param type The type of buffer. Either Stereo or Mono.
 */
+ (instancetype)analyzerWithSamplingRate:(NSUInteger)rate type:(MPKSignalAnalyzerType)type;
/*! @brief Creates a standard analyzer suitable for use with melon headband.
 *
 * @attention +analyzer and +analyzerWithSize: are the preffered ways of creating a analyzer for use with a melon headband.
 *
 * The analyzer created by this method will be a stereo analyzer with the default sampling rate of 250hz, the analyzer size will be 
 * 1000 (4 seconds of data).
 * @returns A analyzer ready to use with a melon headband.
 */
+ (instancetype)analyzer;
/*! @brief Creates a standard analyzer suitable for use with melon headband.
 *
 * @attention +analyzer and +analyzerWithSize: are the preffered ways of creating a analyzer for use with a melon headband.
 *
 * The analyzer created by this method will be a stereo analyzer with the default sampling rate of 250hz, the analyzer size is set 
 * by the size parameter. The size must be at equal to or greater than the next power of 2 following the sampling rate (i.e 
 * 256)
 *
 * @attention Using a analyzer size less than 500 may result in inaccurate signal validation. The performance gain of using a 
 * analyzer size smaller than 1000 is negliable. If you would like to minimize CPU usage, adjust the analysisFactor instead.
 *
 * @returns A analyzer ready to use with a melon headband.
 */

+ (instancetype)analyzerWithSize:(NSUInteger)size;


 
/*! @brief sets a filter to be applied to signal
 *
 * @param filter The filter to be applied.
 * @attention If the analyzer is a Stereo buffer, this filter will be duplicated and applied seperatly to each channel.
 */
- (void)setFilter:(id <MPKFilter>)filter;

/*! @brief the filter being applied to both channels of the filter
 *
 * @return a copy of the filter being applied to both channels of the buffer.
 */
- (id <MPKFilter>)filter;
/*! @brief The filter for the left channel
 *
 * @return An object conforming to the MPKFilter protocol
 */
- (id <MPKFilter>)leftChannelFilter;
/*! @brief The filter for the right channel
 *
 * @return An object conforming to the MPKFilter protocol
 */
- (id <MPKFilter>)rightChannelFilter;


/*! @brief Adds an object conforming to the MPKSignalAnalyzerOutput protocol as an output to the buffer
 *
 */
- (void)addOutput:(id<MPKSignalAnalyzerOutput>)output;

/*! @brief Removes an object conforming to the MPKSignalAnalyzerOutput protocol as an output from the buffer
 *
 */
- (void)removeOutput:(id<MPKSignalAnalyzerOutput>)output;
/*! @brief Removes an outputs from the buffer.
 *
 */
- (void)removeAllOutputs;

/*! @brief Indicates whether or not the signal analyzer is idle.
 *
 * The signal analyzer will go idle when there is no valid signal for at least 10 seconds.
 * When the stream is idle you will no longer recieve analysis results and your streamAnalysisRate is ignored.
 *
 *
 * @return YES if stream is idle NO otherwise.
 *
 */
- (BOOL)isIdle;
/*! @brief Adds a data processor to the stream buffer.
 *
 *
 */
- (void)addDataProcessor:(id<MPKDataProcessor>)processer;
/*! @brief Removes a data processor from the stream buffer.
 *
 *
 */
- (void)removeDataProcessor:(id<MPKDataProcessor>)processer;
/*! @brief An array of all the data processors in the buffer.
 */

- (NSArray *)allDataProcessors;
/*! @brief An array of all the outputs in the buffer.
 */

- (NSArray *)allOutputs;
/*! @brief checks if the analyzer contains an output
 * @return YES if the analyzer contains the outupt, NO otherwise.
 */

- (BOOL)containsOutput:(id<MPKSignalAnalyzerOutput>)output;

/*! @brief Removes the analyzer from the signal stream it is currently added to.
 *
 */
- (void)removeFromSignalStream;
/*! @brief Resets the analyzer to it's default state. This will call -removeFromSignalStream;
 *
 */

- (void)reset;
- (NSTimeInterval)convertFrequencyToTimeInterval:(NSUInteger)frequency;
/*! @brief Creates the default filter for streaming with a melon headband for use in north america.
 * This filter includes a notch filter at 60hz and a bandpass at 1-50hz
 *
 */

+ (id<MPKFilter>)defaultHeadbandFilter;


@end


@protocol MPKSignalAnalyzerDelegate <NSObject>
@optional
- (BOOL)signalAnalyzerShouldEnterIdleState:(MPKSignalAnalyzer *)analyzer;
- (BOOL)signalAnalyzerShouldLeaveIdleState:(MPKSignalAnalyzer *)analyzer;


@end
/*! @brief The protocol all analyzer outputs must conform to in order to process data from the buffer.
 *
 */
@protocol MPKSignalAnalyzerOutput <NSObject>
@optional
- (void)signalAnalyzerDidFinishCalibration:(MPKSignalAnalyzer *)analyzer;
/*! @brief Invoked when the analyzer has entered idle state
 *
 * @param analyzer In idle state
 *
 */
- (void)signalAnalyzerDidEnterIdleState:(MPKSignalAnalyzer *)analyzer;
/*! @brief Invoked when the analyzer has left idle state
 *
 * @param analyzer no longer in idle state
 *
 */
- (void)signalAnalyzerDidLeaveIdleState:(MPKSignalAnalyzer *)analyzer;

/*! @brief Invoked when the analyzer properties change (i.e samplingRate or bufferSize)
 *
 * @param analyzer The analyzer that's properties have changed
 *
 */
- (void)signalAnalyzerDidPerformAnalysis:(MPKSignalAnalyzer *)analyzer onChannels:(MPKChannelSet *)channels;

/*! @brief Specifies the priority of this output.
 *  You may want some outputs to process data before or after other outputs. By specifying a lower number you guarentee that your output will have its methods called before outputs
 *with higher numbers.
 *
 * @param analyzer The stream that contains the output
 */
- (NSUInteger)outputPriorityForSignalAnalyzer:(MPKSignalAnalyzer *)analyzer;
/*! @brief Invoked when the analyzer completes one cycle
 *
 * @param analyzer The analyzer that finished a cycle
 *
 *
 */
- (void)signalAnalyzerDidCompleteCycle:(MPKSignalAnalyzer *)analyzer;
/*! @brief The queue the methods should be called back in.
 *
 * Not implementing this method or returning nil results in the main queue being used.
 */
- (dispatch_queue_t)methodInvocationQueueForSignalAnalyzer:(MPKSignalAnalyzer *)analyzer;
@end