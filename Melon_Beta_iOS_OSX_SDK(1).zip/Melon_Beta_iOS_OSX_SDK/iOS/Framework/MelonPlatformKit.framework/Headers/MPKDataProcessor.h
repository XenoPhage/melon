//
//  MPKSignalProcessor.h
//  MelonPlatformKit
//
//  Created by Eric Lundquist on 9/3/14.
//  Copyright (c) 2014 Melon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MPKChannelDescription.h"
@class MPKSignalAnalyzer;

/*! @brief A protocol that any algoritms, signal analyzers or monitors should conform to.
 *
 * Classes that conform to MPKDataProcessor are allowed process data and generate results as soon as it's recieved by the stream buffer.
 * A a class conforming to MPKDataProcessor usually acts as an algorithm, an idle/invalid signal detector, or both.
 * It must take data from the MPKChannelDescription object passed to it, generate a result and copy any relevant results back to the MPKChannelDescription.
 *
 * An example of an MPKDataProcessor is the MPKFourierTransform. It takes the signal data stored in the MPKChannelDescription, computes the FFT and stores its results
 * in the filteredSignalAmpltude, rawAmplitude, filteredFrequencies, rawFrequencies, filteredDCOffset, and rawDCOffset properties of the MPKChannelDescription.
 *
 * MPKDataProcessor's should ALWAYS copy results they want to persist down the chain of data processers back to the MPKChannelDescription.
 *
 * NOTE: Keep in mind that MPKChannelDescription classes are special dynamic classes that allow you to add values to them dynamically during runtime via KVC. You should never
 * attempt to set the defined properties manually, they are reservered for already existing MelonPlatformKit classes(i.e MPKFourierTransform). This includes overriding the value
 * of a define property using KVC.
 *
 *      Invalid Use:
 *         [channelDesc setValue:myValue forKey:@"filteredAmplitude"];//filteredAmplitude is property that already exists by default.
 *      Valid Use:
 *         [channelDesc setValue:myValue forKey:@"myCustomFilteredAmplitude"];
 *
 * @attention: Classes conforming to MPKDataProcessor should be able to run in near real time. MPKDataProcessor aren't for doing long running or expensive computations. If your class needs to process large amounts of data or spends longer than ~8ms to compute it's results, your class should be an output to the stream analyzer instead.
 */
@protocol MPKDataProcessor <NSObject>
@optional
/*! @brief An optional method that returns the priority the data proccessor should run at.
 *
 * Priorities are useful when chaining data proccessors together.
 * For example say you have two classes conforming to MPKDataProcessor, class A and class B.
 * Class A locates all of the peaks over a certain threshold in MPKChannelDescription's filteredSignal property and stores their indices in the key @"peakThresholdIndices"
 * Class B uses the values in @"peakThresholdIndices" for template matching.
 *
 * @attention: Priorities must be greater than or equal to 0, negative priorites are reserved for internal MelonPlatformKit classes.
 */
- (NSInteger)dataProcessorPriority;
/*! @brief Tells the stream analyzer that this class is capable of detecting idle or invalid signal.
 *
 * This method should return YES if the class is capable of determining whether or not signal is valid/idle.
 *
 * @attention: Priorities must be greater than or equal to 0, negative priorites are reserved for internal MelonPlatformKit classes.
 */
- (BOOL)supportsIdleSignalRecognition;
/*! @brief Tells the stream analyzer that your class has recognized and idle or invalid signal.
 *
 * This method should return YES if the class determined this signal is idle/invalid.
 *
 *
 */
- (BOOL)idleSignalRecognized;

/*! @brief Tells the stream analyzer that your class requires that both channels be updated regardless of whether or not the
 * data processor type for your class is enabled on that channel.
 *
 * Signal stream buffers can enable/disable processor types on a per channel basis. This method allows your class to 
 * force an update of specific type on every channel. Returning YES when the type specified by your class is disabled only 
 * causes your class to have it's update methods invoked, other classes with the same type will not be affected by this.
 * 
 * @attention Returning YES does not mean your class will always be updated, if neither the left or right channel has this 
 * data processers type enabled, then your classes update methods will not be called.
 *
 */
- (BOOL)requiresUpdateToApplyToAllChannels;

@required
/*! @brief This method is called by the analyzer when the analyzer itself is reset. Use it to reset your data processor.
 *
 *
 * @attention Implementing it is highly encouraged.
 *
 */
- (void)resetWithAnalyzer:(MPKSignalAnalyzer *)analyzer;
/*! @brief The type of data processer.
 *
 * Specifying an approriate type for your processor allows stream analyzer objects to better manage what processors are allowed to run.
 
 * Return An MPKDataProcesserType value.
 *
 */
- (MPKDataProcesserType)dataProcessorType;

/*! @brief Allows your class to prepare itself for the incoming description and specify whether or not it would like to be skipped.
 *
 * Return YES if your class if ready to have its updateChannelDescription method called or return NO to skip it.
 *
 * NOTE: Your class IS allowed to make changes to the MPKChannelDescription, but it should only do so if this method returns yes.
 */
- (BOOL)prepareToUpdateChannelDescription:(MPKChannelDescription *)description;
/*! @brief Called when your class should make it's updates to the MPKChannelDescription. This is where any semi computationally expensive results should be computed.
 *
 * Return YES if your class was able to successfully update the description. No otherwise.
 *
 *
 */
- (BOOL)updateChannelDescription:(MPKChannelDescription *)description;
@end

