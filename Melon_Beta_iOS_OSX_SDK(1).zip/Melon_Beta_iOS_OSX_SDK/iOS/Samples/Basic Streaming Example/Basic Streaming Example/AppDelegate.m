//
//  AppDelegate.m
//  Basic Streaming Example
//
//  Created by Eric Lundquist on 3/18/15.
//  Copyright (c) 2015 DAQRI. All rights reserved.
//

#import "AppDelegate.h"
@import MelonPlatformKit;
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [MelonPlatformKit handleApplicationLaunch];//must be called before any other use of the API...
    return YES;
}


@end
